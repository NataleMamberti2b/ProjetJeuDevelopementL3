package com.mygdx.game.graphical;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;

public class FightMenuItem {
    public TextureAtlas.AtlasRegion region;
    public int x;
    public int y;

    public FightMenuItem(TextureAtlas.AtlasRegion s, int x, int y){
        this.x = x;
        this.y = y;
        this.region = s;
    }
}
