package com.mygdx.game.graphical;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.basics.*;
import com.mygdx.game.basics.Character;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.File;
import java.util.ArrayList;

public class Fight {
    private PokeJavGame game;
    private Pokemon currentPokemon;
    private Pokemon currentOpponent;
    private Pokemon[] team;
    private Pokemon[] opponentTeam;
    private int opponentTeamId = 0;
    private int numberPokemonOponent;
    private ArrayList<Move> currentPokemonMoves;
    private String dresseur;

    private org.jdom2.Document document;
    private Element racine;
    StretchViewport port = new StretchViewport(480,320);

    private Texture backGround;
    private TextureAtlas fightUi;
    private ArrayList<FightMenuItem>  textures;
    private Stage texts;
    private Skin skin;
    private Skin skinBig;
    private TextPrompter prompter;

    private int position = 0;
    private int maxpos = 4;
    private boolean waitForKeyUp = false;
    private boolean isYourTurn = true;
    private Move yourMove;
    private Move opponentMove;
    private int waitingEndPrompt = 0;
    private String[] fightTexts;//lenght = 2 contain the two part of a turn text (one per move)
    private Move firstMove;//move who will be executed first (between yours and oponent move
    private Move secondMove;

    private Character player;

    //health
    private ShapeRenderer shapeRenderer;
    private Color green1 = new Color(88/255f,208/255f,128/255f,1);
    private Color green2 = new Color(112/255f,248/255f,168/255f,1);
    private Color orange2 = new Color(248/255f,224/255f,56/255f,1);
    private Color orange1 = new Color(200/255f,168/255f,8/255f,1);
    private Color red2 = new Color(248/255f,88/255f,56/255f,1);
    private Color red1 = new Color(168/255f,64/255f,72/255f,1);
    private Color blue_xp = new Color(64/255f,200/255f,248/255f,1);
    private int[] healthBarpos = {348,132,    104,248};

    public int arrowX;
    public int arrowY;
    public int state = 0;


    public Fight(String opponent,Character player,PokeJavGame game){

        fightUi = new TextureAtlas(Gdx.files.internal("sprites/fightUi.atlas"));
        skin = new Skin(Gdx.files.internal("commodore/font normal/uiskin.json"));

        skinBig = new Skin(Gdx.files.internal("commodore/font big/uiskinBig.json"));

        this.game = game;
        prompter = game.getPrompt();

        texts = new Stage(port);

        this.player = player;

        shapeRenderer = new ShapeRenderer();
        //ON RECUPERE LES INFORMATIONS SUR LE COMBAT/L'ADVERSAIRE
        //On crée une instance de SAXBuilder
        SAXBuilder sxb = new SAXBuilder();
        try
        {
            //On crée un nouveau document JDOM avec en argument le fichier XML
            document = sxb.build(new File("opponents/"+opponent + ".xml"));
        }
        catch(Exception e){}

        //On initialise un nouvel élément racine avec l'élément racine du document.
        racine = document.getRootElement();
        this.dresseur = racine.getChildText("name");
        this.numberPokemonOponent = Integer.parseInt(racine.getChild("nombreDePokemon").getText());
        opponentTeam = new Pokemon[numberPokemonOponent];
        for (int i = 0; i < numberPokemonOponent; i++) {
            opponentTeam[i] = new Pokemon(Integer.parseInt(racine.getChildText("pokemonLvl"+i)),racine.getChildText("pokemon"+i));
        }
        int numberOfMovesToAdd = Integer.parseInt(racine.getChildText("movesNumber"));
        for (int i = 0; i < numberOfMovesToAdd; i++) {
            opponentTeam[i/4].setMove(racine.getChildText("move"+i));
        }

        backGround = new Texture(Gdx.files.internal("sprites/fightBaseBack.png"));

        {
            textures = new ArrayList<>();
            textures.add(new FightMenuItem(fightUi.findRegion("playerPokemon"), 252, 98));
            textures.add(new FightMenuItem(fightUi.findRegion("oponentPokemon"), 26, 230));
            textures.add(new FightMenuItem(fightUi.findRegion("basicBar"), 240, 0));
            textures.add(new FightMenuItem(fightUi.findRegion("attackBar"), 0, 0));
            textures.add(new FightMenuItem(fightUi.findRegion("selectArrow"), 252, 98));
            textures.add(new FightMenuItem(fightUi.findRegion("selectArrowWhite"), 252, 98));
            textures.add(new FightMenuItem(fightUi.findRegion("playerPokemon"), 252, 98));
        }
        int i = 0;
        while (player.getTeam()[i].isKo()){
            i++;
        }
        currentPokemon = player.getTeam()[i];
        currentPokemonMoves = currentPokemon.getPokeMoves();
        currentOpponent = opponentTeam[0];
        refreshTexts();

    }
    public void fightGestion(){
        currentPokemonMoves = currentPokemon.getPokeMoves();
        refreshTexts();
        if(isYourTurn){
            waitingEndPrompt = 0;
            if (state == 0) {
                //refreshArrow
                if (position == 0) {
                    arrowX = 258;
                    arrowY = 50;
                } else if (position == 1) {
                    arrowX = 370;
                    arrowY = 50;
                } else if (position == 2) {
                    arrowX = 258;
                    arrowY = 18;
                } else {
                    arrowX = 370;
                    arrowY = 18;
                }
            }
            else{
                //refreshArrow
                if (position == 0) {
                    arrowX = 18;
                    arrowY = 55;
                } else if (position == 1) {
                    arrowX = 163;
                    arrowY = 55;
                } else if (position == 2) {
                    arrowX = 18;
                    arrowY = 23;
                } else {
                    arrowX = 163;
                    arrowY = 23;
                }
            }

            if (waitForKeyUp == false){
                waitForKeyUp = true;
                //moveArrows
                if (Gdx.input.isKeyPressed(Input.Keys.UP)){
                    if (position != 0 && position!=1){
                        position= position-2;
                    }
                }
                else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)){
                    if (position != 3 && position != 2){
                        position = position+2;
                        if(position>maxpos){
                            position = maxpos;
                        }
                    }
                }
                else if (Gdx.input.isKeyPressed(Input.Keys.LEFT)){
                    if (position != 0 && position!=2){
                        position--;
                    }
                }
                else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
                    if (position != 1 && position != 3){
                        position++;
                        if(position>maxpos){
                            position = maxpos;
                        }
                    }
                }

                else if (Gdx.input.isKeyPressed(Input.Keys.SPACE)){
                    if(state == 0){
                        if (position == 0){
                            state = 1;
                            refreshTexts();
                            maxpos  = currentPokemon.getNbMoves()-1;
                        }else if(position == 1){
                            //bag
                        }else if(position == 2){
                            PokeJavGame.setIsInMenu(true);
                        }else if(position == 3){
                            //fuite
                        }
                    }else{
                        yourMove = currentPokemon.getPokeMoves().get(position);
                        state = 0;
                        //lauch capacity
                        isYourTurn = false;
                        waitingEndPrompt = 0;
                        position = 0;
                    }
                }
                else if (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)){
                    if(state == 1){
                        state = 0;
                        refreshTexts();
                        maxpos  = 4;
                    }
                }
                else {
                    waitForKeyUp = false;
                }
                //moveFleche(348,280-(position*100));
            } //your turn
            else {
                if(!Gdx.input.isKeyPressed(Input.Keys.ANY_KEY)){
                    waitForKeyUp = false;
                }
            }
        }
        else if (waitingEndPrompt == 1) {
            if (game.getPrompt().isIsPrompterAcive() == false){
                Pokemon temp = applyMove(secondMove);
                if (temp != null){
                    game.getPrompt().setText(fightTexts[waitingEndPrompt] + fainted(temp));
                }
                else{
                    game.getPrompt().setText(fightTexts[waitingEndPrompt]);
                }
                refreshTexts();
                displayHealthBars();
                waitingEndPrompt += 1;
            }

        }else if (waitingEndPrompt == 2) {
            if (game.getPrompt().isIsPrompterAcive() == false){
                if (currentPokemon.isKo()){
                    if (player.isTeamKo()){
                        game.setIsFighting(false);
                    }
                    else {
                        //choix pokemon
                        PokeJavGame.setIsInMenu(true);
                    }
                }
                else if(currentOpponent.isKo()){
                    opponentTeamId += 1;
                    if (opponentTeamId>opponentTeam.length-1){
                        //fin du combat
                        game.setIsFighting(false);

                    }
                    else {
                        currentOpponent = opponentTeam[opponentTeamId];
                        game.getPrompt().setText(dresseur + " envoie " + currentOpponent.getName() + " au combat");
                    }
                }
                else {
                    isYourTurn = true;
                    waitingEndPrompt = 0;
                    maxpos  = 4;
                }
            }

        }
        else if(game.getIsInMenu()){

        }
        else {
            setOponentMove();
            fightTexts = generateFightTexts(yourMove,opponentMove);
            Pokemon temp = applyMove(firstMove);
            if (temp != null){
                System.out.println(temp);
                game.getPrompt().setText(fightTexts[waitingEndPrompt] + fainted(temp));
                waitingEndPrompt = 2;
            }
            else {
                game.getPrompt().setText(fightTexts[waitingEndPrompt]);

                waitingEndPrompt += 1;
            }
            refreshTexts();
            displayHealthBars();
        }
    }

    private void refreshTexts(){
        texts.clear();
        Label pokeName = new Label(currentPokemon.getName(),skin);
        Label pokeLvl = new Label("Lv"+currentPokemon.getLvl(),skin);
        Label oponentName = new Label(currentOpponent.getName(),skin);
        Label oponentLvl = new Label("Lv"+currentOpponent.getLvl(),skin);
        Label life = new Label(currentPokemon.getActualLife()+"/ "+Integer.toString(currentPokemon.getMaxLife()),skin);
        String[] attaques = new String[4];
        if (isYourTurn){
            for (int i = 0; i < currentPokemonMoves.size(); i++) {
                if(currentPokemonMoves.get(i)==null){
                    attaques[i] ="---";
                }
                else {
                    attaques[i] = currentPokemonMoves.get(i).getName();
                }

            }
            if(state == 1) {
                Label attaque1 = new Label(attaques[0], skin);
                Label attaque2 = new Label(attaques[1], skin);
                Label attaque3 = new Label(attaques[2], skin);
                Label attaque4 = new Label(attaques[3], skin);

                attaque1.setPosition(35, 53);
                attaque2.setPosition(180, 53);
                attaque3.setPosition(35, 21);
                attaque4.setPosition(180, 21);

                texts.addActor(attaque1);
                texts.addActor(attaque2);
                texts.addActor(attaque3);
                texts.addActor(attaque4);
            }
        }

        pokeName.setPosition(280,142);
        pokeLvl.setPosition(444-pokeLvl.getWidth(),142);
        oponentName.setPosition(40,258);
        oponentLvl.setPosition(200-oponentLvl.getWidth(),258);
        life.setPosition(441-life.getWidth(),107);



        texts.addActor(pokeName);
        texts.addActor(pokeLvl);
        texts.addActor(oponentName);
        texts.addActor(oponentLvl);
        texts.addActor(life);

    }

    public void displayHealthBars(){
        //96*4,   96*2
        Color[] colors = {green1,green2,orange1,orange2,red1,red2};
        Color color1;
        Color color2;
        //shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        //port.apply();
        Pokemon[] pokemons = {currentPokemon,currentOpponent};
        ArrayList<HealthBarToPrint> res = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            float rapport = (float) pokemons[i].getMaxLife()/pokemons[i].getActualLife();
            int w = (int) (96/rapport);
            if(rapport>=2){
                if(rapport>=7){
                    color1 = red1;
                    color2 = red2;
                }else{
                    color1 = orange1;
                    color2 = orange2;
                }
            }
            else {
                color1 = green1;
                color2 = green2;
            }
            res.add(new HealthBarToPrint(color1,healthBarpos[i*2],healthBarpos[2*i+1]+4,w));
            res.add(new HealthBarToPrint(color2,healthBarpos[i*2],healthBarpos[2*i+1],w));
            //shapeRenderer.setColor(color1);
            //shapeRenderer.rect(healthBarpos[i*2],healthBarpos[2*i+1]+4,w,2);
            //shapeRenderer.setColor(color2);
            //shapeRenderer.rect(healthBarpos[i*2],healthBarpos[2*i+1],w,4);
        }
        //shapeRenderer.end();
        PokeJavGame.setHealthBarInfos(res);
    }

    public Pokemon applyMove(Move move){
        if (move == yourMove){
            if (yourMove.apply(currentPokemon, currentOpponent)){
                return currentOpponent;
            }
        }
        else {
            if (opponentMove.apply(currentPokemon, currentPokemon)) {
                return currentPokemon;
            }
        }
        return null;
    }

    public String[] generateFightTexts(Move yourMove, Move oponentMove){
        ArrayList<String> a;
        ArrayList<String> b;
        String[] fightTexts = new String[2];
        if (yourMove.getPriority()<oponentMove.getPriority()){
            firstMove = oponentMove;
            secondMove = yourMove;
            a = new ArrayList<>(lauch(currentOpponent,currentPokemon,oponentMove));
            b = new ArrayList<>(lauch(currentPokemon,currentOpponent,yourMove));
        }
        else if (yourMove.getPriority()>oponentMove.getPriority()){
            firstMove = yourMove;
            secondMove = oponentMove;
            a = new ArrayList<>(lauch(currentPokemon,currentOpponent,yourMove));
            b = new ArrayList<>(lauch(currentOpponent,currentPokemon,oponentMove));
        }
        else if (currentOpponent.getSpeed()>currentPokemon.getSpeed()){
            firstMove = oponentMove;
            secondMove = yourMove;
            a = new ArrayList<>(lauch(currentOpponent,currentPokemon,oponentMove));
            b = new ArrayList<>(lauch(currentPokemon,currentOpponent,yourMove));
        }
        else {
            firstMove = yourMove;
            secondMove = oponentMove;
            a = new ArrayList<>(lauch(currentPokemon,currentOpponent,yourMove));
            b = new ArrayList<>(lauch(currentOpponent,currentPokemon,oponentMove));
        }
        String text1 = "";
        String text2 = "";
        for (int i = 0; i < a.size(); i++) {
            text1 += a.get(i) + "%";
        }
        for (int i = 0; i < b.size(); i++) {
            text2 += b.get(i) + "%";
        }
        fightTexts[0] = text1;
        fightTexts[1] = text2;
        return fightTexts;
    }

    public ArrayList<String> lauch(Pokemon launcher, Pokemon receiver,Move move){
        if (move.getClass().getName() == "com.mygdx.game.basics.OffensiveMove"){
            return offensiveMoveText(launcher,receiver,move);
        }
        else if(move.getClass().getName() == "com.mygdx.game.basics.EffectMove"){
            return effectMoveText(launcher,receiver,(EffectMove) move);
        }
        else {
            return statMoveText(launcher,receiver,(StatsMove) move);
        }
    }

    public ArrayList<String> offensiveMoveText(Pokemon launcher, Pokemon receiver,Move move){
        ArrayList<String> res = new ArrayList<>();
        String s = launcher.getName()+" utilise%"+move.getName()+"!";
        res.add(s);
        //test precision reussite
        float effectiveness = TypeTable.getEffectiveness(receiver.getTypeElement().ordinal(),move.getTypeElement().ordinal());
        if(effectiveness==1.5){
            res.add("C'est tres efficace!");
        }
        else if(effectiveness==0.5){
            res.add("Ce n'est pas tres efficace");
        }
        return res;
    }

    public ArrayList<String> effectMoveText(Pokemon launcher, Pokemon receiver, EffectMove move){
        ArrayList<String> res = new ArrayList<>();
        String s = launcher.getName()+" utilise%"+move.getName()+"!";
        res.add(s);
        //test precision reussite
        res.add(receiver.getName()+ move.getEffectString());
        return res;
    }

    public ArrayList<String> statMoveText(Pokemon launcher, Pokemon receiver,StatsMove move){
        ArrayList<String> res = new ArrayList<>();
        String s = launcher.getName()+" utilise%"+move.getName()+"!";
        res.add(s);
        String[] parts = move.getStatModifierString().split("&");
        s = parts[0];
        if (move.getSelf() == false){
            s += receiver.getName();
        }
        else {
            s += launcher.getName();
        }
        s += parts[1];
        res.add(s);
        return res;
    }

    public String  fainted(Pokemon pokemon){

        PokeJavGame.fightTeamMenuTransition = true; //ne pas oublier de passer false à la fin
        return "%" +pokemon.getName() + " est KO !";

    }
    public void setOponentMove(){
        opponentMove = currentOpponent.getPokeMoves().get(0);
    }
    public Texture getBackGround(){return backGround;}
    public ArrayList<FightMenuItem> getTextures(){
        return textures;
    }
    public int getState(){return state;}
    public Stage getTexts(){return texts;}
    public boolean getIsYourTurn(){return isYourTurn;}
    public Pokemon getCurrentPokemon(){
        return currentPokemon;
    }
    public void setCurrentPokemon(Pokemon pokemon){
        currentPokemon = pokemon;
    }
    public Pokemon getCurrentOponent(){
        return currentOpponent;
    }
    public void endFight(){
        game.setIsFighting(false);
        currentPokemon.editStats();
    }
}
