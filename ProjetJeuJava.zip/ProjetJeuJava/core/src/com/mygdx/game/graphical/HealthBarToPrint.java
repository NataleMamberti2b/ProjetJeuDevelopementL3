package com.mygdx.game.graphical;

import com.badlogic.gdx.graphics.Color;

public class HealthBarToPrint {
    Color color;
    public int x;
    public int y;
    public int w;

    public HealthBarToPrint(Color color,int x, int y, int w){
        this.color= color;
        this.x = x;
        this.y = y;
        this.w = w;

    }

}
