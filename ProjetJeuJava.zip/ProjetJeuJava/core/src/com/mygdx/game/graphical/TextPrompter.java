package com.mygdx.game.graphical;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

import java.util.ArrayList;

public class TextPrompter {
    private Stage linesEncapsulator;
    private Skin skinBig;
    private Skin skinSmall;
    private Texture promptBack;
    private static boolean isPrompterAcive = false;
    private boolean waitForKeyUp = false;

    private Label line1;
    private Label line2;
    private String text;
    private ArrayList<String> lines;

    public TextPrompter(){
        promptBack = new Texture("sprites/promptBack.png");
        skinSmall = new Skin(Gdx.files.internal("commodore/font normal/uiskin.json"));
        skinBig = new Skin(Gdx.files.internal("commodore/font big/uiskinBig.json"));

        lines = new ArrayList<String>();
        linesEncapsulator = new Stage();
        line1 = new Label("",skinBig);//35
        line2 = new Label("",skinBig);

        line1.setPosition(32,62);
        line2.setPosition(32,32);

        linesEncapsulator.addActor(line1);
        linesEncapsulator.addActor(line2);

    }

    public void prompter(){
        if (isIsPrompterAcive()){
            if (waitForKeyUp == false){
                waitForKeyUp = true;
                if (Gdx.input.isKeyPressed(Input.Keys.ENTER)||Gdx.input.isKeyPressed(Input.Keys.SPACE)){
                    if(!nextLine()){
                        text = "";
                        setIsPrompterAcive(false);
                        resetLines();
                        if (PokeJavGame.fightTeamMenuTransition){
                            PokeJavGame.resetToWait();
                        }
                    }
                    else if (line1.getText().toString() == ""){
                        nextLine();
                    }
                }
                else {
                    waitForKeyUp = false;
                }
            }
            else {
                if(!Gdx.input.isKeyPressed(Input.Keys.ANY_KEY)){
                    waitForKeyUp = false;
                }
            }
        }

    }

    private boolean nextLine(){
        line1.setText(line2.getText());
        if(lines.size()>0){
            line2.setText(lines.remove(0));
            return true;
        }
        else{
            line2.setText("");
            return false;
        }
    }
    private void splitLines(){
        String[] linesTemp = text.split("%");
        for (int i = 0; i < linesTemp.length; i++) {
            if(linesTemp[i].length()>32){
                lines.add(linesTemp[i].substring(0,33));
                linesTemp[i] = linesTemp[i].substring(33);
                i--;
            }
            else {
                lines.add(linesTemp[i]);
            }

        }

        line1.setText(lines.remove(0));
        if (lines.size()!=0){
            line2.setText(lines.remove(0));
        }
    }
    public static void setIsPrompterAcive(boolean newVal){
        isPrompterAcive = newVal;
    }
    public void setText(String newText){
        setIsPrompterAcive(true);
        text = newText;
        splitLines();
    }

    public Stage getLines(){return linesEncapsulator;}
    public Texture getPromptBack(){return promptBack;}
    public boolean isIsPrompterAcive(){
        return isPrompterAcive;
    }
    public void resetLines(){line1.setText("");line2.setText("");}
}
