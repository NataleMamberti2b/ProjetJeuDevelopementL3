package com.mygdx.game.graphical;

import com.badlogic.gdx.maps.MapProperties;

public class Event {
    private EventType type;
    private String text;
    private String oponent;
    public boolean isValid = true;

    public Event(String eventType, MapProperties props){
        if (eventType.equals("fight")){
            this.type = EventType.FIGHT;
            this.oponent = props.get("opponent").toString();
        }
        else if(eventType.equals("dialogue")){
            this.type = EventType.DIALOGUE;
            this.oponent = props.get("text").toString();
        }
        else{
            this.isValid = false;
        }
    }
    public EventType getType(){return type;}
    public String getOponent(){return oponent;}
    public String getText(){return text;}
}
