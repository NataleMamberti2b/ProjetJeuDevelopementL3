package com.mygdx.game.graphical;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.basics.Character;
import com.mygdx.game.basics.Pokemon;

import java.util.ArrayList;

public class PokeMenu {
    //principalMenu
    private Skin uiSkin;
    private Skin uiSkinBig;
    private Label equipe;
    private Label save;
    private Label exit;
    private Label fleche;

    private Stage menu ;
    private ShapeRenderer shapeRenderer;


    //teamMenu
    private TextureAtlas teamMenuRessource;
    private Stage pokemonMenu;
//65 90      47
    //nav variables
    private int state = 0;
    private int position = 0;
    private int maxPos = 2;
    private boolean waitForKeyUp = false;

    private SpriteBatch pokeBatch;
    private ArrayList<TeamMenuItem> baseItems;
    private Pokemon[] team;
    private Pokemon selected;
    private int numbersOfPokemonsInTeam;
    private float[] pokemonInfoPosInMenuX;
    private float[] pokemonInfoPosInMenuY;

    //life bar colors
    private Color green1 = new Color(88/255f,208/255f,128/255f,1);
    private Color green2 = new Color(112/255f,248/255f,168/255f,1);
    private Color orange2 = new Color(248/255f,224/255f,56/255f,1);
    private Color orange1 = new Color(200/255f,168/255f,8/255f,1);
    private Color red2 = new Color(248/255f,88/255f,56/255f,1);
    private Color red1 = new Color(168/255f,64/255f,72/255f,1);
    private Color blue_xp = new Color(64/255f,200/255f,248/255f,1);
    private int[] healthBarpos = {64,196,    368,278,    368,230,    368,182,    368,134,     368,86};
    private boolean mustDisplayHealthBars = false;
    StretchViewport port = new StretchViewport(480,320);

    public PokeMenu(PokeJavGame game){

        //Pokemons
        team = Character.getPokemons();
        numbersOfPokemonsInTeam = getNbElements(team);

        //principalMenu
        shapeRenderer = game.getShapeRenderer();

        menu = new Stage(port);
        uiSkin = new Skin(Gdx.files.internal("commodore/font normal/uiskin.json"));
        uiSkinBig = new Skin(Gdx.files.internal("commodore/font big/uiskinBig.json"));
        equipe = new Label("POKEMON",uiSkinBig);
        save = new Label("SAVE",uiSkinBig);
        exit = new Label("EXIT",uiSkinBig);
        fleche = new Label(">",uiSkinBig);

        equipe.setPosition(360,280);
        save.setPosition(360,180);
        exit.setPosition(360,80);
        fleche.setPosition(352,280);

        menu.addActor(equipe);
        menu.addActor(save);
        menu.addActor(exit);
        menu.addActor(fleche);

        //pokemonMenu                       Nom                                   LVL                      Vie
        pokemonMenu = new Stage(port);//        1    2      3  4  5  6         // 1    2  3    4  5  6            1    2    3  4  5  6
        pokemonInfoPosInMenuX = new float[]{64 , 236, 236, 236, 236, 236,    80, 252, 252, 252, 252, 252,   102, 466, 466, 466, 466, 466 };
        pokemonInfoPosInMenuY = new float[]{226, 274, 226, 178, 130, 82,    204, 252, 204, 156, 108, 60,    170, 252, 204, 156, 108, 60  };
        addPokemonsText();


        teamMenuRessource = new TextureAtlas(Gdx.files.internal("sprites/UIdouble.atlas"));
        pokeBatch = PokeJavGame.getBatch();

        baseItems = new ArrayList<TeamMenuItem>();{
        baseItems.add(new TeamMenuItem("principalBack",0,0));//0

        baseItems.add(new TeamMenuItem("pokeBarEmpty",96,128));//1
        baseItems.add(new TeamMenuItem("pokeBarEmpty",96,104));//2
        baseItems.add(new TeamMenuItem("pokeBarEmpty",96,80));//3
        baseItems.add(new TeamMenuItem("pokeBarEmpty",96,56));//4
        baseItems.add(new TeamMenuItem("pokeBarEmpty",96,32));//5


        baseItems.add(new TeamMenuItem("pokePrincipal",8,85));//6

        baseItems.add(new TeamMenuItem("pokeBar",96,128));//2nd pokemon//7
        baseItems.add(new TeamMenuItem("pokeBar",96,104));//3rd//8
        baseItems.add(new TeamMenuItem("pokeBar",96,80));//9
        baseItems.add(new TeamMenuItem("pokeBar",96,56));//10
        baseItems.add(new TeamMenuItem("pokeBar",96,32));//6th//11

        baseItems.add(new TeamMenuItem("cancel",186,10));//6


        baseItems.add(new TeamMenuItem("miniPoke",2,118));//6th//17
        baseItems.add(new TeamMenuItem("miniPoke",88,127));//1st//12
        baseItems.add(new TeamMenuItem("miniPoke",88,103));//2nd//13
        baseItems.add(new TeamMenuItem("miniPoke",88,79));//3rd//14
        baseItems.add(new TeamMenuItem("miniPoke",88,55));//15
        baseItems.add(new TeamMenuItem("miniPoke",88,31));//16

        baseItems.add(new TeamMenuItem("miniPoke",184,6));//cancel//18


        baseItems.add(new TeamMenuItem("pokePrincipalActivated",8,85));//19

        baseItems.add(new TeamMenuItem("pokeBarActivated",96,128));
        baseItems.add(new TeamMenuItem("pokeBarActivated",96,104));
        baseItems.add(new TeamMenuItem("pokeBarActivated",96,80));
        baseItems.add(new TeamMenuItem("pokeBarActivated",96,56));
        baseItems.add(new TeamMenuItem("pokeBarActivated",96,32));

        baseItems.add(new TeamMenuItem("cancelSelected",185,10));

        baseItems.add(new TeamMenuItem("miniPokeActivated",2,118));//1st
        baseItems.add(new TeamMenuItem("miniPokeActivated",87,127));//2nd
        baseItems.add(new TeamMenuItem("miniPokeActivated",88,103));//3rd
        baseItems.add(new TeamMenuItem("miniPokeActivated",88,79));
        baseItems.add(new TeamMenuItem("miniPokeActivated",88,55));
        baseItems.add(new TeamMenuItem("miniPokeActivated",88,31));//6th


        baseItems.add(new TeamMenuItem("miniPokeActivated",184,6));//cancel
        }
    }

    public Stage getMenu(){
        if (state == 10){
            return pokemonMenu;
        }else {
            return menu;
        }
    }

    public void navigate(){

        if (state == 0){
            renderBackground();
            if (!waitForKeyUp){
                waitForKeyUp = true;
                if (Gdx.input.isKeyPressed(Input.Keys.UP)){
                    if (position != 0){
                        position--;
                    }
                }
                else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)){
                    if (position != maxPos){
                        position++;
                    }
                }
                else if (Gdx.input.isKeyPressed(Input.Keys.ENTER)){
                    if (position == 2){
                        PokeJavGame.setIsInMenu(false);
                        PokeJavGame.resetToWait();
                        state = 0;
                    }
                    else {
                        state = position + 10;
                    }
                    position = 0;
                }
                else if (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)){
                    PokeJavGame.setIsInMenu(false);
                    PokeJavGame.resetToWait();
                }
                else {
                    waitForKeyUp = false;
                }
                moveFleche(348,280-(position*100));
            }
            else {
                if(!Gdx.input.isKeyPressed(Input.Keys.ANY_KEY)){
                    waitForKeyUp = false;
                }
            }
        }
        else if(state == 10){
            team();
        }


        //(Gdx.input.isKeyPressed(Input.Keys.DOWN))
    }

    public void renderBackground(){
        if (state == 0){
            shapeRenderer.setColor(Color.WHITE);
            shapeRenderer.rect(333,3,144,314);
            shapeRenderer.setColor(Color.GRAY);
            shapeRenderer.rect(337,7,136,306);
            shapeRenderer.end();
        }
    }

    public void moveFleche(float x, float y){
        fleche.setPosition(x,y);
    }

    public void team(){
        maxPos = numbersOfPokemonsInTeam;
        addPokemonsText();


        drawElements(baseItems,position);
        mustDisplayHealthBars = true;

        if (waitForKeyUp == false){
            waitForKeyUp = true;
            if (Gdx.input.isKeyPressed(Input.Keys.UP)){
                if (position == 0){
                    position = maxPos;
                }
                else if(position==6 && numbersOfPokemonsInTeam<6){
                    position = numbersOfPokemonsInTeam-1;
                }
                else {
                    position--;
                }
            }
            else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)){
                if (position == maxPos || position == 6){
                    position=0;
                }
                else {
                    position++;
                }
            }
            else if (Gdx.input.isKeyPressed(Input.Keys.ENTER)){
                if (position == maxPos || position == 6){
                    PokeJavGame.resetToWait();
                    state = 0;
                    position = 0;
                    mustDisplayHealthBars  = false;
                }
                else {
                    state = 15;
                }
                position = 0;
            }
            else if (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)){
                state = 0;
                position = 0;
                PokeJavGame.resetToWait();
                mustDisplayHealthBars = false;
            }
            else if (Gdx.input.isKeyPressed(Input.Keys.SPACE)){
                if (!team[position].isKo()){
                    state = 0;
                    PokeJavGame.resetToWait();
                    mustDisplayHealthBars = false;
                    selected = team[position];
                    position = 0;
                }
            }
            else {
                waitForKeyUp = false;
            }

            if (position == maxPos){
                position = 6;
            }
        }
        else {
            if(!Gdx.input.isKeyPressed(Input.Keys.ANY_KEY)){
                waitForKeyUp = false;
            }
        }

    }

    public void drawElements(ArrayList<TeamMenuItem> list, int position){
        for (int i = 0; i < 6 ; i++) {
            TeamMenuItem tmp = list.get(i);
            TextureAtlas.AtlasRegion textureTmp = teamMenuRessource.findRegion(tmp.name);
            pokeBatch.draw(textureTmp,tmp.x*2,tmp.y*2f,textureTmp.originalWidth,textureTmp.originalHeight);

        }

        for (int i = 6; i < 13 ; i++) {
            if (i != position + 6){//si i n'est pas égal à la position actuelle
                if (i-6!=6){
                    if (team[i-6] != null){
                        TeamMenuItem tmp = list.get(i);
                        TextureAtlas.AtlasRegion textureTmp = teamMenuRessource.findRegion(tmp.name);
                        pokeBatch.draw(textureTmp,tmp.x*2,tmp.y*2f,textureTmp.originalWidth,textureTmp.originalHeight);

                        tmp = list.get(i+7);
                        textureTmp = teamMenuRessource.findRegion(tmp.name);
                        pokeBatch.draw(textureTmp,tmp.x*2,tmp.y*2f,textureTmp.originalWidth,textureTmp.originalHeight);
                    }
                }
                else {
                    TeamMenuItem tmp = list.get(i);
                    TextureAtlas.AtlasRegion textureTmp = teamMenuRessource.findRegion(tmp.name);
                    pokeBatch.draw(textureTmp,tmp.x*2,tmp.y*2f,textureTmp.originalWidth,textureTmp.originalHeight);

                    tmp = list.get(i+7);
                    textureTmp = teamMenuRessource.findRegion(tmp.name);
                    pokeBatch.draw(textureTmp,tmp.x*2,tmp.y*2f,textureTmp.originalWidth,textureTmp.originalHeight);
                }

            }
            else{//affiche le pokemon selectionne
                TeamMenuItem tmp = list.get(i+14);
                TextureAtlas.AtlasRegion textureTmp = teamMenuRessource.findRegion(tmp.name);
                pokeBatch.draw(textureTmp,tmp.x*2,tmp.y*2f,textureTmp.originalWidth,textureTmp.originalHeight);

                tmp = list.get(i+21);
                textureTmp = teamMenuRessource.findRegion(tmp.name);
                pokeBatch.draw(textureTmp,tmp.x*2,tmp.y*2f,textureTmp.originalWidth,textureTmp.originalHeight);
            }
        }

    }

    public int getNbElements(Pokemon[] team){
        int count = 0;
        for (int i = 0; i < team.length ; i++) {
            if (team[i] != null){
                count++;
            }
        }
        return count;
    }

    public void addPokemonsText(){
        pokemonMenu.clear();
        ArrayList<Label> labels = new ArrayList<>();
        for (int i = 0; i < numbersOfPokemonsInTeam; i++) {
            labels.add( new Label(team[i].getName(),uiSkin));
            pokemonMenu.addActor(labels.get(0+ 3*i));
            labels.get(0+ 3*i).setPosition(pokemonInfoPosInMenuX[i],pokemonInfoPosInMenuY[i]);
            pokemonMenu.addActor(labels.get(0+ 3*i));

            labels.add(new Label("Lv"+Integer.toString(team[i].getLvl()), uiSkin));
            pokemonMenu.addActor(labels.get(1+ 3*i));
            labels.get(1+ 3*i).setPosition(pokemonInfoPosInMenuX[i+6],pokemonInfoPosInMenuY[i+6]);
            pokemonMenu.addActor(labels.get(1+ 3*i));

            labels.add(new Label(team[i].getActualLife()+"/"+ team[i].getMaxLife(), uiSkin));
            pokemonMenu.addActor(labels.get(2+ 3*i));
            float wdt = labels.get(2+ 3*i).getWidth();
            labels.get(2+ 3*i).setPosition(pokemonInfoPosInMenuX[i+12]-wdt,pokemonInfoPosInMenuY[i+12]);
            pokemonMenu.addActor(labels.get(2+ 3*i));
        }
        labels.add((new Label("CANCEL",uiSkin)));
        pokemonMenu.addActor(labels.get(18));
        labels.get(18).setPosition(408,23);
    }

    public void displayHealthBar(){
        //96*4,   96*2

        Color[] colors = {green1,green2,orange1,orange2,red1,red2};
        Color color1;
        Color color2;

        for (int i = 0; i < team.length; i++) {
            float rapport = (float) team[i].getMaxLife()/team[i].getActualLife();
            int w = (int) ((96/rapport));
            if(rapport>=2){
                if(rapport>=7){
                    color1 = red1;
                    color2 = red2;
                }else{
                    color1 = orange1;
                    color2 = orange2;
                }
            }
            else {
                color1 = green1;
                color2 = green2;
            }
            shapeRenderer.setColor(color1);
            shapeRenderer.rect(healthBarpos[i*2],healthBarpos[2*i+1]+4,w,2);
            shapeRenderer.setColor(color2);
            shapeRenderer.rect(healthBarpos[i*2],healthBarpos[2*i+1],w,4);
        }
    }

    public boolean isMustDisplayHealthBars(){
        return mustDisplayHealthBars;
    }
    public void setState(int state){
        this.state = state;
    }
    public Pokemon getSelected(){
        return selected;
    }
    public void resetSelected(){
        selected = null;
    }

}
