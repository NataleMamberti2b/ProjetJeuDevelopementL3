package com.mygdx.game.graphical;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;

public class PokeMap {
    private AssetManager manager;
    private TiledMap tiledMap;

    private TiledMapTileLayer collideLayer;
    boolean[][][] collideTiles;

    public PokeMap(){
        manager = new AssetManager();
        manager.setLoader(TiledMap.class, new TmxMapLoader());
        manager.load("mapTest2.tmx", TiledMap.class);
        manager.finishLoading();
        tiledMap = manager.get("mapTest2.tmx", TiledMap.class);


        MapProperties properties = tiledMap.getProperties();
        int tileWidth         = properties.get("tilewidth", Integer.class);
        int tileHeight        = properties.get("tileheight", Integer.class);
        int mapWidthInTiles   = properties.get("width", Integer.class);
        int mapHeightInTiles  = properties.get("height", Integer.class);

        collideLayer = (TiledMapTileLayer) tiledMap.getLayers().get(1);
        collideTiles = new boolean[mapWidthInTiles][mapHeightInTiles][2];
        for (int i = 0; i < mapWidthInTiles; i++) {
            for (int j = 0; j < mapHeightInTiles; j++) {
                MapProperties tmp = collideLayer.getCell(i,j).getTile().getProperties();
                collideTiles[i][j][0] = (boolean) tmp.get("isValid");
                //collideTiles[i][j][1] = (boolean) tmp.get("isWarp");
            }
        }
    }


    public TiledMap getTiledMap(){
        return tiledMap;
    }
    public void managerDispose(){
        manager.dispose();
    }
    public boolean getCollideTiles(int i,int j,int k){
        return collideTiles[i][j][k];
    }
    public Event getEvent(int x, int y,int stance){
        MapProperties tmp;
        if (stance == 0){
            tmp  = collideLayer.getCell(x,y-1).getTile().getProperties();
        }
        else if (stance == 1){
            tmp  = collideLayer.getCell(x-1,y).getTile().getProperties();
        }
        else if (stance == 2){
            tmp  = collideLayer.getCell(x+1,y).getTile().getProperties();
        }
        else {
            tmp  = collideLayer.getCell(x,y+1).getTile().getProperties();
        }
        Event event = new Event(tmp.get("event").toString(),tmp);
        if (event.isValid){
            return event;
        }
        else {
            return null;
        }
    }
}
