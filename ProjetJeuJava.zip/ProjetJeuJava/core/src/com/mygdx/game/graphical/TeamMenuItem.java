package com.mygdx.game.graphical;

public class TeamMenuItem {
    public String name;
    public int x;
    public int y;

    public TeamMenuItem(String s,int x,int y){
        this.x = x;
        this.y = y;
        this.name = s;
    }
}
