package com.mygdx.game.graphical;

public enum EventType {
    FIGHT,
    DIALOGUE
}
