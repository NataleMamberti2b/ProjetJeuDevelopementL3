package com.mygdx.game.graphical;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.mygdx.game.basics.Character;

import java.util.ArrayList;

public class PokeJavGame extends ApplicationAdapter {

	enum Screen{
		TITLE, MAIN_GAME, FIGHT;
	}
	//basics
	private Screen currentScreen = Screen.MAIN_GAME;
	private static SpriteBatch batch;
	private Camera camera;
	private OrthogonalTiledMapRenderer renderer;

	private static final int VIRTUAL_WIDTH = 480;
	private static final int VIRTUAL_HEIGHT = 320;
	private static final float ASPECT_RATIO = (float)VIRTUAL_WIDTH/(float)VIRTUAL_HEIGHT;
	private Rectangle viewport;

	//map
	private static PokeMap THEmap;//Class
	private TiledMap map;
	private int tileWidth, tileHeight,
			mapWidthInTiles, mapHeightInTiles,
			mapWidthInPixels, mapHeightInPixels;
	//collide detection
	private TiledMapTileLayer collideLayer;
	boolean[][][] collideTiles;

	//character
	private Character character;//Class
	TextureRegion currentFrame;

	//UiMenu
	private Skin uiSkin;
	private Label equipe;
	private Label save;
	private Label exit;
	private Label fleche;


	private PokeMenu menu ;//Class
	private ShapeRenderer shapeRenderer;
	private static float toWait = 0;
	private TextPrompter prompt;

	public static boolean fightTeamMenuTransition = false;
	//UiFight
	private Fight fight;
	private static ArrayList<HealthBarToPrint> healthBarInfos = new ArrayList<>();

	//stateBooleans
	private static boolean isInMenu;
	private static boolean isFighting;
	private boolean speakingToSomeone = true;
	private boolean prompterEnd = false;

	@Override
	public void create () {


		batch = new SpriteBatch();
		shapeRenderer = new ShapeRenderer();

		character  = new Character(this);
		THEmap = new PokeMap();
		prompt = new TextPrompter();
		prompt.setText("zyyyyyyyyy % zddddddddddddddddd%zddddddddd%dzzdzdzzokdacc");

		character.setTHEmap();


		map = THEmap.getTiledMap();
		MapProperties properties = map.getProperties();
		tileWidth         = properties.get("tilewidth", Integer.class);
		tileHeight        = properties.get("tileheight", Integer.class);
		mapWidthInTiles   = properties.get("width", Integer.class);
		mapHeightInTiles  = properties.get("height", Integer.class);

		collideLayer = (TiledMapTileLayer) map.getLayers().get(1);
		collideTiles = new boolean[mapWidthInTiles][mapHeightInTiles][2];
		for (int i = 0; i < mapWidthInTiles; i++) {
			for (int j = 0; j < mapHeightInTiles; j++) {
				MapProperties tmp = collideLayer.getCell(i,j).getTile().getProperties();
				collideTiles[i][j][0] = (boolean) tmp.get("isValid");
				//collideTiles[i][j][1] = (boolean) tmp.get("isWarp");
			}
		}

		MapProperties tileProperties = collideLayer.getCell(1,0).getTile().getProperties();
		mapWidthInPixels  = mapWidthInTiles  * tileWidth;
		mapHeightInPixels = mapHeightInTiles * tileHeight;

		camera = new OrthographicCamera(VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
		camera.position.x = 240;
		camera.position.y = 140;


		currentFrame = (character.getCurrentFrame(0));

		renderer = new OrthogonalTiledMapRenderer(map);
	}

	@Override
	public void render () {
		if(prompterEnd == true){
			speakingToSomeone = false;
		}
		camera.update();

		// set viewport
		Gdx.gl.glViewport((int) viewport.x, (int) viewport.y,
				(int) viewport.width, (int) viewport.height);

		// clear previous frame
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		renderer.setView((OrthographicCamera) camera);
		renderer.render();

		batch.begin();
		shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
		batch.draw(currentFrame,224,160);

		//camera.position.y = camera.position.y + 1f;
		if(isFighting){
			displayFightGeneral();
			batch.draw(character.getCharset().findRegion("emptyFrame"),0,0);
			displayFightTexts();
			if(toWait>=0.1f){
				fight.fightGestion();
				if (isInMenu){
					if(menu == null){
						menu = new PokeMenu(this);
					}
					menu.team();
					batch.draw(character.getCharset().findRegion("emptyFrame"),0,0);
					menu.setState(10);
					menu.getMenu().draw();
					if(menu.getSelected() != null){
						fight.setCurrentPokemon(menu.getSelected());
						menu.resetSelected();
						setIsInMenu(false);
					}
				}
			}
			else {
				toWait = toWait + Gdx.graphics.getDeltaTime();
			}
			/*
			1:FOND+POKEMONS,BARRESDEVIE,ECT...
			2:PROMPT
			3:OPTIONS TO CHOOSE*/

		}
		else if (isInMenu){
			if (toWait >= 0.05f){
				menu.navigate();
				batch.draw(character.getCharset().findRegion("emptyFrame"),0,0);
				menu.getMenu().draw();
			}
			else {
				toWait = toWait + Gdx.graphics.getDeltaTime();
			}

		}

		//PROMPT
		else if(speakingToSomeone){
			display_prompt();
		}
		else {
			if (toWait >= 0.5f){
				character.move();
			}
			else {
				toWait = toWait + Gdx.graphics.getDeltaTime();
			}
			if (character.getIsMoving()){
				// Getting the frame we must draw at this moment
				character.setElapsed_time(character.getElapsed_time()+Gdx.graphics.getDeltaTime());
				currentFrame = character.getCurrentFrame();
			}
			else {
				currentFrame = (character.getCurrentFrame(0));
			}
			camera.position.x = character.getPosx();
			camera.position.y = character.getPosy();

			batch.draw(currentFrame,224,160);
		}

		batch.end();
		if(isInMenu){
			if(menu == null){
				menu = new PokeMenu(this);
			}
			if (menu.isMustDisplayHealthBars()) {
				menu.displayHealthBar();
			}
		}
		if (isFighting && !isInMenu){
			fight.displayHealthBars();
			for (int i = 0; i < 2; i++) {
				HealthBarToPrint part1 = healthBarInfos.get(i*2);
				shapeRenderer.setColor(part1.color);
				shapeRenderer.rect(part1.x,part1.y,part1.w,2);
				HealthBarToPrint part2 = healthBarInfos.get(i*2+1);
				shapeRenderer.setColor(part2.color);
				shapeRenderer.rect(part2.x,part2.y,part2.w,4);
			}
		}//HealthBarDisplay

		shapeRenderer.end();
	}

	@Override
	public void dispose () {
		map.dispose();
		THEmap.managerDispose();
		renderer.dispose();
	}


	public boolean[][][] getCollideTiles(){
		return collideTiles;
	}

	public static void setIsInMenu(boolean newValue){
		isInMenu = newValue;
	}

	public static PokeMap getTHEmap(){
		return THEmap;
	}
	public static void resetToWait(){
		toWait = 0;
	}
	public static void setToWait(float newVal){
		toWait = newVal;
	}
	public static SpriteBatch getBatch(){
		return batch;
	}
	private void display_prompt(){
		batch.draw(prompt.getPromptBack(),0,0);
		prompt.prompter();
		batch.draw(character.getCharset().findRegion("emptyFrame"),0,0);
		prompt.getLines().draw();
		if (!prompt.isIsPrompterAcive()){
			prompterEnd = true;
		}
	}
	private void displayFightGeneral(){
		batch.draw(fight.getBackGround(),0,96);
		display_prompt();
		ArrayList<FightMenuItem> items =  fight.getTextures();
		for (int i = 0; i < 3; i++) {
			FightMenuItem item = items.get(i);
			batch.draw(item.region,item.x,item.y);
		}
		if(fight.getIsYourTurn()){
			if (fight.getState()==1){
				batch.draw(items.get(3).region,0,0);
				batch.draw(items.get(5).region,fight.arrowX,fight.arrowY);
			}
			else {

				batch.draw(items.get(4).region,fight.arrowX,fight.arrowY);
			}
		}
		else {
			display_prompt();
		}
		if(!fight.getCurrentPokemon().isKo()){
			batch.draw(fight.getCurrentPokemon().getBack(),84,68);
		}
		if(!fight.getCurrentOponent().isKo()){
			batch.draw(fight.getCurrentOponent().getFace(),288,148);
		}
	}
	private void displayFightTexts(){
		fight.getTexts().draw();
	}


	public void setIsFighting(boolean newVal){
		isFighting = newVal;
		if (isFighting==false){
			fight = null;
		}
	}
	public void setFight(Fight newFight){
		this.fight = newFight;
	}
	public TextPrompter getPrompt() { return prompt;}
	public static void setHealthBarInfos(ArrayList<HealthBarToPrint> array){
		healthBarInfos = array;
	}
	public boolean getIsInMenu(){
		return isInMenu;
	}

	public ShapeRenderer getShapeRenderer(){return shapeRenderer;}

	@Override
	public void resize(int width, int height)
	{
		// calculate new viewport
		float aspectRatio = (float)width/(float)height;
		float scale = 1f;
		Vector2 crop = new Vector2(0f, 0f);
		if(aspectRatio > ASPECT_RATIO)
		{
			scale = (float)height/(float)VIRTUAL_HEIGHT;
			crop.x = (width - VIRTUAL_WIDTH*scale)/2f;
		}
		else if(aspectRatio < ASPECT_RATIO)
		{
			scale = (float)width/(float)VIRTUAL_WIDTH;
			crop.y = (height - VIRTUAL_HEIGHT*scale)/2f;
		}
		else
		{
			scale = (float)width/(float)VIRTUAL_WIDTH;
		}

		float w = (float)VIRTUAL_WIDTH*scale;
		float h = (float)VIRTUAL_HEIGHT*scale;
		viewport = new Rectangle(crop.x, crop.y, w, h);
	}
}