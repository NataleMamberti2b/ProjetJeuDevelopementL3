/*
 * Nom de classe : Move
 *
 * Description   : description de la classe et de son rôle
 *
 * Version       : 1.0
 *
 * Date          : 20/01/2021
 *
 * Copyright     : Natale
 */
package com.mygdx.game.basics;

public abstract class Move {
    protected int         precision;
    protected int         pouvoir;
    protected int         priority;
    protected TypeElement type;
    protected String      name;

    protected int     PP;
    protected int     actualPP;
    protected Pokemon pokemon;



    public Move(){
        actualPP = PP;
    }

    public Move(Pokemon detenteur){
        pokemon = detenteur;
        actualPP = PP;
    }

    public abstract boolean apply(Pokemon lanceur, Pokemon adverse);



    public String getName() {
        return name;
    }
    public TypeElement getTypeElement(){return type;}
    public int getPriority(){return priority;}

    @Override
    public String toString(){
        return super.toString() + " / "+name;
    }

    public String toString(int i){
        if (i==0){
            return super.toString();
        }
        else if(i==1) {
            return name;
        }
        else {
            return super.toString() + " / "+name;
        }
    }
}
