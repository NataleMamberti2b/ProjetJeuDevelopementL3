/*
 * Nom de classe : Pokemon
 *
 * Description   : description de la classe et de son rôle
 *
 * Version       : 1.0
 *
 * Date          : 20/01/2021
 *
 * Copyright     : Natale
 */
package com.mygdx.game.basics;

import com.badlogic.gdx.graphics.Texture;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.File;
import java.rmi.UnexpectedException;
import java.util.ArrayList;
import java.util.List;


public class Pokemon {
    private int lvl;
    private int actualLife;
    //Stats
    private int maxLife;
    private int attack;
    private int defense;
    private int sAttack;
    private int sDefense;
    private int speed;
    //Xp
    private int xp;
    private int toNextLevel;

    //Stats for calculus and random
    private       int attackIV;
    private final int BASE_ATTACK;
    private       int defenseIV;
    private final int BASE_DEFENSE;
    private       int SattackIV;
    private final int BASE_SPE_ATTACK;
    private       int SdefenseIV;
    private final int BASE_SPE_DEFENSE;
    private       int lifeIV;
    private final int BASE_LIFE;
    private       int speedIV;
    private final int BASE_SPEED;
    private boolean KO = false;
    private float precision = 1;

    private String evolution;
    private int evolutionLevel;

    private String name;
    private TypeElement type;
    private ArrayList<Move> pokeMoves = new ArrayList<>();
    private ArrayList<String> moveLearningList = new ArrayList<>();
    private ArrayList<Integer> moveLearningLevels = new ArrayList<>();
    private Character owner;
    private Effect status;

    //graphics
    private Element racine = new Element("Pokemon");
    private org.jdom2.Document document;
    private Texture face;
    private Texture back;

    public Pokemon(int lvl, String name) {
        this.name = name;
        this.lvl = lvl;
        this.xp = getXpFromLvl(lvl);
        this.toNextLevel = getXpFromLvl(lvl+1);

        face = new Texture("sprites/faces/"+name+".png");
        back = new Texture("sprites/backs/"+name+".png");

        //On crée une instance de SAXBuilder
        SAXBuilder sxb = new SAXBuilder();
        try
        {
            //On crée un nouveau document JDOM avec en argument le fichier XML
            document = sxb.build(new File("pokemons/"+name + ".xml"));
        }
        catch(Exception e){}

        //On initialise un nouvel élément racine avec l'élément racine du document.
        racine = document.getRootElement();
        this.BASE_ATTACK = Integer.parseInt(racine.getChild("baseA").getText());
        this.BASE_DEFENSE = Integer.parseInt(racine.getChild("baseD").getText());
        this.BASE_LIFE = Integer.parseInt(racine.getChild("baseL").getText());
        this.BASE_SPEED = Integer.parseInt(racine.getChild("baseS").getText());
        this.BASE_SPE_ATTACK = Integer.parseInt(racine.getChild("baseSa").getText());
        this.BASE_SPE_DEFENSE = Integer.parseInt(racine.getChild("baseSd").getText());
        this.type = TypeElement.valueOf(racine.getChild("type").getText());
        try
        {
            String[] tmp = racine.getChildText("evolution").split("%");
            evolutionLevel = Integer.parseInt(tmp[0]);
            evolution = tmp[1];
        }
        catch(Exception e){}



        Element moves = racine.getChild("moves");
        List listMove = moves.getChildren("move");
        Element levels = racine.getChild("levels");
        List listLevel = levels.getChildren("level");



        editMoves(listMove, listLevel);

        this.lifeIV = (int)(Math.random() * 16);
        this.attackIV = (int)(Math.random() * 16);
        this.defenseIV = (int)(Math.random() * 16);
        this.speedIV = (int)(Math.random() * 16);
        this.SattackIV = (int)(Math.random() * 16);
        this.SdefenseIV = (int)(Math.random() * 16);

        editStats();
    }
    public Pokemon(int lvl, String name, int attackIV,int defenseIV, int sattackIV,int sdefenseIV, int lifeIV, int speedIV) {
        this.name = name;
        this.lvl = lvl;
        this.xp = getXpFromLvl(lvl);
        this.toNextLevel = getXpFromLvl(lvl+1);

        face = new Texture("sprites/faces/"+name+".png");
        back = new Texture("sprites/backs/"+name+".png");

        //On crée une instance de SAXBuilder
        SAXBuilder sxb = new SAXBuilder();
        try
        {
            //On crée un nouveau document JDOM avec en argument le fichier XML
            document = sxb.build(new File("pokemons/"+name + ".xml"));
        }
        catch(Exception e){}

        //On initialise un nouvel élément racine avec l'élément racine du document.
        racine = document.getRootElement();
        this.BASE_ATTACK = Integer.parseInt(racine.getChild("BASE_ATTACK").getText());
        this.BASE_DEFENSE = Integer.parseInt(racine.getChild("BASE_DEFENSE").getText());
        this.BASE_LIFE = Integer.parseInt(racine.getChild("BASE_LIFE").getText());
        this.BASE_SPEED = Integer.parseInt(racine.getChild("BASE_SPEED").getText());
        this.BASE_SPE_ATTACK = Integer.parseInt(racine.getChild("BASE_SPE_ATTACK").getText());
        this.BASE_SPE_DEFENSE = Integer.parseInt(racine.getChild("BASE_SPE_DEFENSE").getText());
        this.type = TypeElement.valueOf(racine.getChild("type").getText());
        try
        {
            String[] tmp = racine.getChildText("evolution").split("%");
            evolutionLevel = Integer.parseInt(tmp[0]);
            evolution = tmp[1];
        }
        catch(Exception e){}



        Element moves = racine.getChild("moves");
        List listMove = moves.getChildren("move");
        Element levels = racine.getChild("levels");
        List listLevel = levels.getChildren("level");



        editMoves(listMove, listLevel);
        editStats();

    }

    private void editMoves(List listMove,List levels){
        for (int i = 0; i<listMove.size();i++) {
            String e = ((Element)listMove.get(i)).getText();
            int level = Integer.parseInt(((Element)levels.get(i)).getText());
            moveLearningLevels.add(level);
            moveLearningList.add(e);
            if (lvl>=moveLearningLevels.get(i)){
                switch (e.charAt(0)){
                    case 'O':
                        pokeMoves.add(new OffensiveMove(e,this));
                        break;
                    case 'E':
                        pokeMoves.add(new EffectMove(e,this));
                        break;
                    case 'S':
                        pokeMoves.add(new StatsMove(e,this));
                        break;
                }

                if (pokeMoves.size()>4){
                    pokeMoves.remove(0);
                }
            }

        }
        for (int i = 0; i < pokeMoves.size()-4; i++) {
            listMove.set(4-i,null);
        }
    }

    public void setMove(String toAdd){
        String e = toAdd;
        switch (e.charAt(0)){
            case 'O':
                pokeMoves.add(new OffensiveMove(e,this));
                break;
            case 'E':
                pokeMoves.add(new EffectMove(e,this));
                break;
            case 'S':
                pokeMoves.add(new StatsMove(e,this));
                break;
        }
        if (pokeMoves.size()>4){
            pokeMoves.remove(0);
        }

    }

    private int calculLife(){
        return (((2*BASE_LIFE + lifeIV + 31) * lvl )/100) + lvl + 10;
    }

    private int calculAtt(){
        return (((2*BASE_ATTACK + attackIV + 31) * lvl)/100 + 5);
    }
    private int calculDef(){
        return (((2*BASE_DEFENSE + defenseIV + 31) * lvl)/100 + 5);
    }
    private int calculStatGeneric(int BASE_SPEEDtat, int ivStat){
        return (((2*BASE_SPEEDtat + ivStat + 31) * lvl)/100 + 5);
    }

    public void editStats(){
        this.maxLife = calculLife();
        this.actualLife = this.maxLife;
        this.attack = calculAtt();
        this.defense = calculDef();
        this.speed = calculStatGeneric(BASE_SPEED, speedIV);
        this.sAttack = calculStatGeneric(BASE_SPE_ATTACK,SattackIV);
        this.sDefense = calculStatGeneric(BASE_SPE_DEFENSE,SdefenseIV);
        precision = 1;
    }

    public void addXp(int gain) throws UnexpectedException {
        xp = xp + gain;
        if (xp>toNextLevel){
            lvl++;
            toNextLevel = getXpFromLvl(lvl+1);
            if (lvl>evolutionLevel){
                Pokemon tmp = new Pokemon(lvl, evolution);
                for (int i = 0; i < pokeMoves.size(); i++) {
                    tmp.setMove(pokeMoves.get(i).getName());
                }
                tmp.setIVs(getattackIV(),getdefenseIV(),getSattackIV(),getSdefenseIV(),getlifeIV(),getspeedIV());
                Pokemon[] team = owner.getTeam();
                for (int i = 0; i < team.length; i++) {
                    if(team[i] == this){
                        team[i] = tmp;
                        return;
                    }
                    else {
                        throw new UnexpectedException("Pokemon of team not in team !?");
                    }
                }
            }
            else {
                for (int i = 0; i < moveLearningLevels.size(); i++) {
                    if (moveLearningLevels.get(i)==lvl){
                        this.setMove(moveLearningList.get(i));
                    }
                }
                editStats();
            }
        }
    }

    //Getters


    public int getXpFromLvl(int lvl){
        //return (int) (25 * (1-Math.pow(1.2,lvl-5))/(1-1.2));
        return (int) Math.pow(lvl,3);
    }

    public int getLvl() {
        return lvl;
    }

    public int getXp() {
        return xp;
    }

    public int getToNextLevel() {
        return toNextLevel;
    }

    public TypeElement getTypeElement(){
        return type;
    }

    public String getName(){
        return name;
    }


    /* Stats */

    public int getMaxLife() {
        return maxLife;
    }

    public int getActualLife() {
        return actualLife;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpeAttack() {
        return sAttack;
    }

    public int getSpeDefense() {
        return sDefense;
    }

    public int getSpeed() { return speed; }

    public int getNbMoves(){return pokeMoves.size();}

    public ArrayList<Move> getPokeMoves(){return pokeMoves;}

    public void setKO(Boolean KO) {
        this.KO = KO;
    }

    public Texture getFace() {
        return face;
    }

    public Texture getBack() {
        return back;
    }

    public boolean isKo(){
        return KO;
    }

    /* Setters */

    public void setXp(int xp) {
        this.xp = xp;
    }

    public void setActualLife(int actualLife){
        this.actualLife = actualLife;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public void setsAttack(int sAttack) {
        this.sAttack = sAttack;
    }

    public void setsDefense(int sDefense) {
        this.sDefense = sDefense;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void setPrecision(float precision) {
        this.precision = precision;
    }

    public void setOwner(Character owner){
        this.owner = owner;
    }

    public void setStatus(Effect status) {
        this.status = status;
    }

    /* Iv Getters*/
    public int getattackIV() {
        return attackIV;
    }

    public int getdefenseIV() {
        return defenseIV;
    }

    public int getSattackIV() {
        return SattackIV;
    }

    public int getSdefenseIV() {
        return SdefenseIV;
    }

    public int getlifeIV() {
        return lifeIV;
    }

    public int getspeedIV() {
        return speedIV;
    }

    /* Iv Setters */
    public void setAttackIV(int attackIV) {
        this.attackIV = attackIV;
    }

    public void setDefenseIV(int defenseIV) {
        this.defenseIV = defenseIV;
    }

    public void setSattackIV(int sattackIV) {
        SattackIV = sattackIV;
    }

    public void setSdefenseIV(int sdefenseIV) {
        SdefenseIV = sdefenseIV;
    }

    public void setLifeIV(int lifeIV) {
        this.lifeIV = lifeIV;
    }

    public void setspeedIV(int speedIV) {
        this.speedIV = speedIV;
    }

    public void setIVs(int attackIV,int defenseIV, int sattackIV,int sdefenseIV, int lifeIV, int speedIV){
        this.setAttackIV(attackIV);
        this.setDefenseIV(defenseIV);
        this.setSattackIV(sattackIV);
        this.setSdefenseIV(sdefenseIV);
        this.setLifeIV(lifeIV);
        this.setspeedIV(speedIV);
    }




    @Override
    public String toString(){
        String moves = "";
        for (int i = 0; i < pokeMoves.size(); i++) {
            moves += pokeMoves.get(i).toString(1);
            moves += ", ";
        }
        return name + "|| Pv :"+actualLife+"/"+maxLife + "|| Moves : ["+moves+"]";
    }
}
