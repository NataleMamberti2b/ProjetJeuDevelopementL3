/*
 * Nom de classe : StatsMove
 *
 * Description   : description de la classe et de son rôle
 *
 * Version       : 1.0
 *
 * Date          : 20/01/2021
 *
 * Copyright     : Natale
 */
package com.mygdx.game.basics;

import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.File;

public class StatsMove extends Move {

    private StatModifier statModifier;
    private String statModifierString;
    private boolean self;

    private org.jdom2.Document document;
    private Element racine;

    public StatsMove(String name, Pokemon detenteur, StatModifier modifier){
        this(name, detenteur);
        this.setStatModifier(modifier);
    }

    public StatsMove(String name, Pokemon detenteur){
        super(detenteur);

        SAXBuilder saxbuilder = new SAXBuilder();
        try {
            //On crée un nouveau document JDOM avec en argument le fichier XML
            document = saxbuilder.build(new File("moves/"+name + ".xml"));
        }
        catch(Exception e){
            System.out.println(e + " : "+ name);
        }

        //On initialise un nouvel élément racine avec l'élément racine du document.
        racine = document.getRootElement();
        this.name = racine.getChildText("name");
        precision = Integer.parseInt(racine.getChildText("precision"));
        pouvoir = Integer.parseInt(racine.getChildText("pouvoir"));
        PP = Integer.parseInt(racine.getChildText("PP"));
        type = TypeElement.valueOf(racine.getChildText("type"));
        self = Boolean.parseBoolean(racine.getChildText("self"));
        statModifier = StatModifier.valueOf(racine.getChildText("statModifier"));
        statModifierString = setStatModifierString();
        try {
            priority = Integer.parseInt(racine.getChildText("priority"));
        }//Priority
        catch (Exception e){
            priority = 0;
        }
    }

    @Override
    public boolean apply(Pokemon lanceur, Pokemon adverse) {
        if (self){
            statSelection(lanceur);
        }
        else {
            statSelection(adverse);
        }
        return false;
    }

    public void statSelection(Pokemon pokemon){
        switch (statModifier){
            case BOOST_ATTACK:
                pokemon.setAttack((int) (pokemon.getAttack()*1.5));
                break;
            case BOOST_DEFENSE:
                pokemon.setDefense((int) (pokemon.getDefense()*1.5));
                break;
            case BOOST_SPEATTACK:
                pokemon.setsAttack((int) (pokemon.getSpeAttack()*1.5));
                break;
            case BOOST_SPEDEFENSE:
                pokemon.setsDefense((int) (pokemon.getSpeDefense()*1.5));
                break;
            case BOOST_SPEED:
                pokemon.setSpeed((int) (pokemon.getSpeed()*1.5));
                break;


            case DECREASE_ATTACK:
                pokemon.setAttack((int) (pokemon.getAttack()*0.5));
                break;
            case DECREASE_DEFENSE:
                pokemon.setDefense((int) (pokemon.getDefense()*0.5));
                break;
            case DECREASE_SPEATTACK:
                pokemon.setsAttack((int) (pokemon.getSpeAttack()*0.5));
                break;
            case DECREASE_SPEDEFENSE:
                pokemon.setsDefense((int) (pokemon.getSpeDefense()*0.5));
                break;
            case DECREASE_SPEED:
                pokemon.setSpeed((int) (pokemon.getSpeed()*0.5));
                break;

        }
    }

    private String setStatModifierString(){
        if (statModifier==StatModifier.DECREASE_ATTACK){
            return ("Ah L'attaque de & diminue !");
        }
        else if (statModifier==StatModifier.DECREASE_DEFENSE){
            return "Ah La defense de & diminue !";
        }
        else if (statModifier==StatModifier.DECREASE_SPEATTACK){
            return "Ah L'attaque speciale de & diminue !";
        }
        else if (statModifier==StatModifier.DECREASE_SPEDEFENSE){
            return "Ah La defense speciale de & diminue !";
        }
        else if (statModifier==StatModifier.DECREASE_SPEED){
            return "Ah La vitesse de & diminue !";
        }
        else if (statModifier==StatModifier.BOOST_ATTACK){
            return "Ah L'attaque de & augmente !";
        }
        else if (statModifier==StatModifier.BOOST_DEFENSE){
            return "Ah La defense de & augmente !";
        }
        else if (statModifier==StatModifier.BOOST_SPEATTACK){
            return "Ah L'attaque speciale de & augmente !";
        }
        else if (statModifier==StatModifier.BOOST_SPEDEFENSE){
            return "Ah La defense speciale de & augmente !";
        }
        else if (statModifier==StatModifier.BOOST_SPEED){
            return "Ah La vitesse de & augmente !";
        }
        else
            return null;
    }


    public String getStatModifierString(){return statModifierString;}
    public Boolean getSelf(){
        return self;
    }

    public void setStatModifier(StatModifier statModifier) {
        this.statModifier = statModifier;
    }
}
