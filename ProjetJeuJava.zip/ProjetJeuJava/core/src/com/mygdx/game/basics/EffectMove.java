/*
 * Nom de classe : EffectMove
 *
 * Description   : description de la classe et de son rôle
 *
 * Version       : 1.0
 *
 * Date          : 20/01/2021
 *
 * Copyright     : Natale
 */
package com.mygdx.game.basics;

import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.File;

public class EffectMove extends Move {
    private Effect effect;
    private String effectString;

    private org.jdom2.Document document;
    private Element racine;

    public EffectMove(String name, Pokemon detenteur, Effect effect){
        this(name, detenteur);
        this.setEffect(effect);
    }

    public EffectMove(String name, Pokemon detenteur){
        super(detenteur);
        SAXBuilder sxb = new SAXBuilder();
        try {
            //On crée un nouveau document JDOM avec en argument le fichier XML
            System.out.println("name : "+name);
            document = sxb.build(new File("moves/"+name + ".xml"));
        }
        catch(Exception e){
            System.out.println(e + " : "+ name);
        }

        //On initialise un nouvel élément racine avec l'élément racine du document.
        racine = document.getRootElement();
        this.name = racine.getChildText("name");
        precision = Integer.parseInt(racine.getChildText("precision"));
        pouvoir = Integer.parseInt(racine.getChildText("pouvoir"));
        type = TypeElement.valueOf(racine.getChildText("type"));
        PP = Integer.parseInt(racine.getChildText("PP"));
        effect = Effect.valueOf(racine.getChildText("effect"));
        effectString = setEffectString();

        try {
            priority = Integer.parseInt(racine.getChildText("priority"));
        }//Priority
        catch (Exception e){
            priority = 0;
        }
    }

    @Override
    public boolean apply(Pokemon lanceur, Pokemon adverse){
        return false;
    }


    private String setEffectString(){
        if (effect==Effect.PSN){
            return (" est empoisonné");
        }
        else if (effect==Effect.BURN){
            return " est brulé";
        }
        else if (effect==Effect.PARA){
            return " est paralysé";
        }
        else if (effect==Effect.FRZ){
            return " est gelé";
        }
        else if (effect==Effect.SLP){
            return " s'endort";
        }
        else {
            return " devient confus";
        }
    }


    public String getEffectString() {
        return effectString;
    }

    public void setEffect(Effect effect) {
        this.effect = effect;
    }
}
