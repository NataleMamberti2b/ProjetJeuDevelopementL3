/*
 * Nom de classe : Character
 *
 * Description   : description de la classe et de son rôle
 *
 * Version       : 1.0
 *
 * Date          : 20/01/2021
 *
 * Copyright     : Natale
 */
package com.mygdx.game.basics;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import com.mygdx.game.graphical.*;

public class Character {
    //character

    private float posx = 48+32*5;
    private float posy = 32*5;

    public float targetY = posy;
    public float targetX = posx;

    private boolean isMoving = false;
    private int     stance = 0;
    private int     tileX = 0;
    private int     tileY = 0;
    private float   speed = 2f;
    private PokeMap THEmap;
    private boolean animPendulum;
    //Texture Personnage
    private TextureAtlas charset;
    // Time which each frame keeps on screen
    private static float FRAME_DURATION = 0.240f;
    // walking animations
    private Animation walkingAnimationS;
    private Animation walkingAnimationE;
    private Animation walkingAnimationW;
    private Animation walkingAnimationN;
    private Animation[] walkingAnimations;

    private static Pokemon[] pokemons;

    // Elapsed time
    private float elapsed_time = 0f;
    private PokeJavGame game;


    public Character(Pokemon[] pokemons){
        this.pokemons = pokemons;
    }

    public Character(PokeJavGame pokeGame){

        //definition equipe
        Pokemon first = new Pokemon(18,"SALAMECHE");
        Pokemon second = new Pokemon(50,"SALAMECHE");
        Pokemon third = new Pokemon(35,"RATTATA");
        Pokemon fourth = new Pokemon(1,"SALAMECHE");
        Pokemon fifth = new Pokemon(35,"SALAMECHE");
        Pokemon sixth = new Pokemon(35,"SALAMECHE");


        pokemons = new Pokemon[]{first, second, third, fourth, fifth, sixth};

        for (Pokemon p:pokemons) {
            p.setOwner(this);
        }
        //-----------------Graphical part-----------------------
        charset = new TextureAtlas(Gdx.files.internal("sprites/charset.atlas"));

        // Getting the images for "walking" animation
        Array<TextureAtlas.AtlasRegion> southFrames = charset.findRegions("south");
        Array<TextureAtlas.AtlasRegion> eastFrames = charset.findRegions("east");
        Array<TextureAtlas.AtlasRegion> westFrames = charset.findRegions("west");
        Array<TextureAtlas.AtlasRegion> northFrames = charset.findRegions("north");


        walkingAnimationS = new Animation(FRAME_DURATION, southFrames, Animation.PlayMode.LOOP);
        walkingAnimationE = new Animation(FRAME_DURATION, eastFrames, Animation.PlayMode.LOOP);
        walkingAnimationW = new Animation(FRAME_DURATION, westFrames, Animation.PlayMode.LOOP);
        walkingAnimationN = new Animation(FRAME_DURATION, northFrames, Animation.PlayMode.LOOP);
        walkingAnimations = new Animation[]{walkingAnimationS, walkingAnimationE, walkingAnimationW, walkingAnimationN};

        game = pokeGame;
    }


    public static Pokemon[] getPokemons(){
        return pokemons;
    }
    public Pokemon[] getTeam(){return pokemons;}

    public boolean isTeamKo(){
        for (int i = 0; i < pokemons.length; i++) {
            if (!pokemons[i].isKo()){
                return false;
            }
        }
        return true;
    }

    public void printTeam(){
        System.out.println("---------------------");
        System.out.println("Equipe du joueur :");
        for (int i = 0; i < pokemons.length; i++) {
            System.out.println(pokemons[i]);
        }
    }

    public void addPokemon(Pokemon pokemon){
        for (int i = 0; i < pokemons.length; i++) {
            if (pokemons[i]==null){
                pokemons[i] = pokemon;
                System.out.println("successful");
                return;
            }
        }
        System.out.println("Team is already complete");
        return;
    }


    //-----------------Graphical part-----------------------
    public void move(){
		/*
		if (Gdx.input.isKeyPressed()) {
			speed = 2;
		} else {
			speed = 1;
		}*/

        // Moves the player
        if (isMoving) {
            // Sets the player animation
			/*
			if (speed == 1)
				player.setStance(Stance.WALKING);
			else if (speed == 2)
				player.setStance(Stance.RUNNING);
			*/


            if (posx < targetX) {
                posx =  posx + speed;
            }

            if (posx > targetX) {
                posx =  posx - speed;
            }

            if (posy < targetY) {
                posy =  posy + speed;
            }

            if (posy > targetY) {
                posy =  posy - speed;
            }

            if (Math.abs(posx - targetX) <= 1 && Math.abs(posy-targetY) <= 1) {
                if (animPendulum){
                    elapsed_time = FRAME_DURATION*3;
                }
                else {
                    elapsed_time = FRAME_DURATION;
                }
                animPendulum = !animPendulum;
                posx  = targetX;
                posy = targetY;
                isMoving = false;
            }
        }
        else {
            if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
                stance = 3;
                if (cellAvailable(posx,posy+32)){
                    isMoving = true;
                    targetY = posy + 32;
                    targetX = posx;
                }
            }

            else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
                stance = 0;
                if (cellAvailable(posx,posy-32)) {
                    isMoving = true;
                    targetY = posy - 32;
                    targetX = posx;

                }
            }

            else if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
                stance = 1;
                if (cellAvailable(posx - 32,posy)) {
                    isMoving = true;
                    targetX = posx - 32;
                    targetY = posy;

                }
            }

            else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
                stance = 2;
                if (cellAvailable(posx + 32,posy)) {
                    isMoving = true;
                    targetX = posx + 32;
                    targetY = posy;

                }
            }
            else if (Gdx.input.isKeyPressed(Input.Keys.ENTER)) {
                PokeJavGame.setIsInMenu(true);
                PokeJavGame.resetToWait();
            }
            else if (Gdx.input.isKeyPressed(Input.Keys.SPACE)) {
                Event event = THEmap.getEvent((int)posx/32,(int)posy/32,stance);
                if (event != null){
                    if(event.getType().equals(EventType.FIGHT)){
                        Fight fight = new Fight(event.getOponent(),this,game);
                        PokeJavGame.resetToWait();
                        game.setFight(fight);
                        game.setIsFighting(true);
                    }
                    else {

                    }
                }
            }
            else {
                if (animPendulum){
                    elapsed_time = FRAME_DURATION;
                }
                else {
                    elapsed_time = FRAME_DURATION*3;
                }
            }
        }
    }

    public void setElapsed_time(float time){
        elapsed_time = time;
    }

    public float getElapsed_time(){
        return elapsed_time;
    }

    public TextureRegion getCurrentFrame(float time) {
        return (TextureRegion) walkingAnimations[stance].getKeyFrame(time);
    }
    public TextureRegion getCurrentFrame() {
        return (TextureRegion) walkingAnimations[stance].getKeyFrame(elapsed_time);
    }
    public void setTHEmap(){
        THEmap = PokeJavGame.getTHEmap();
    }
    public boolean cellAvailable(float x, float y){
        int i = (int) x/32;
        int j = (int) y/32;
        THEmap.getCollideTiles(i,j,0);
        try{
            return THEmap.getCollideTiles(i,j,0);
        }
        catch (Exception e){
            return false;
        }

    }


    public float getPosx(){
        return posx;
    }
    public float getPosy(){
        return posy;
    }
    public boolean getIsMoving(){
        return isMoving;
    }

    public TextureAtlas getCharset() {
        return charset;
    }


}
