package com.mygdx.game.basics;

public enum TypeElement {
    ACIER,
    COMBAT,
    DRAGON,
    EAU,
    ELECTRIQUE,
    FEU,
    GLACE,
    INSECTE,
    NORMAL,
    PLANTE,
    POISON,
    PSY,
    ROCHE,
    SOL,
    SPECTRE,
    TENEBRE,
    VOL
}
