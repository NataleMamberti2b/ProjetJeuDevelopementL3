package com.mygdx.game.basics;

public enum StatModifier {
    DECREASE_ATTACK,
    DECREASE_DEFENSE,
    DECREASE_SPEATTACK,
    DECREASE_SPEDEFENSE,
    DECREASE_SPEED,
    BOOST_ATTACK,
    BOOST_DEFENSE,
    BOOST_SPEATTACK,
    BOOST_SPEDEFENSE,
    BOOST_SPEED,
}
