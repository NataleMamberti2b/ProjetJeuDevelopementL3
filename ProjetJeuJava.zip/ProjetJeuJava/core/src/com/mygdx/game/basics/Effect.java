package com.mygdx.game.basics;

public enum Effect {//Effects that can be applied to a pokemon by effectMoves
    BURN,
    PSN,
    PARA,
    SLP,
    FRZ,
    CFS,
}
