package com.mygdx.game.basics;

public class PokemonJavaTest {
    public static void main (String[] arg) {
        Pokemon first = new Pokemon(18,"SALAMECHE");
        Pokemon second = new Pokemon(50,"SALAMECHE");
        Pokemon third = new Pokemon(35,"RATTATA");
        Pokemon fourth = new Pokemon(1,"SALAMECHE");
        Pokemon fifth = new Pokemon(35,"SALAMECHE");
        Pokemon sixth = new Pokemon(35,"SALAMECHE");
        Pokemon[] pokemons = new Pokemon[]{first, second, third, fourth, fifth, sixth};
        Character joueur = new Character(pokemons);

        joueur.printTeam();

    }
}
