/*
 * Nom de classe : OffensiveMove
 *
 * Description   : description de la classe et de son rôle
 *
 * Version       : 1.0
 *
 * Date          : 20/01/2021
 *
 * Copyright     : Natale
 */
package com.mygdx.game.basics;

import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.File;
import java.util.Random;

public class OffensiveMove extends Move {

    private boolean speciale; //Defini si l'attaque est speciale ou non (si elle doit utiliser l'attaque speciale ou simplement l'attaque)
    private float   criticalChance;


    private org.jdom2.Document document;
    private Element racine;

    public OffensiveMove(String name, Pokemon detenteur, float criticalChance){
        this(name, detenteur);
        this.setCriticalChance(criticalChance);
    }
    public OffensiveMove(String name, Pokemon detenteur) {
        super(detenteur);
        SAXBuilder sxb = new SAXBuilder();
        try {
            //On crée un nouveau document JDOM avec en argument le fichier XML
            document = sxb.build(new File("moves/"+name + ".xml"));
        }
        catch(Exception e){
            System.out.println(e + " : "+ name);
        }

        //On initialise un nouvel élément racine avec l'élément racine du document.
        racine = document.getRootElement();
        this.name = racine.getChildText("name");
        precision = Integer.parseInt(racine.getChildText("precision"));
        pouvoir = Integer.parseInt(racine.getChildText("pouvoir"));
        speciale = Boolean.parseBoolean(racine.getChildText("speciale"));
        PP = Integer.parseInt(racine.getChildText("PP"));
        type = TypeElement.valueOf(racine.getChildText("type"));
        try {
            criticalChance = Float.parseFloat(racine.getChildText("crit"));
        }
        catch (Exception e){
            criticalChance = 0.075f;
        }

        try {
            priority = Integer.parseInt(racine.getChildText("priority"));
        }//Priority
        catch (Exception e){
            priority = 0;
        }
    }

    @Override
    public boolean apply(Pokemon lanceur, Pokemon adverse){
        int att;
        int def;
        if(speciale){
            att = pokemon.getSpeAttack();
            def = adverse.getSpeDefense();
        }
        else {
            att = pokemon.getAttack();
            def = adverse.getDefense();
        }
        float mod = calcMod(adverse);
        int cc;
        cc = (Math.random()<=criticalChance) ? 2 : 1;
        double R;
        R = new Random().nextInt(39)+217;
        R = Math.floor((R*100)/255f);
        //int damages = (((( ( (pokemon.getLvl()*2/5) + 2) × Puissance × Att[Spé] ÷ 50) ÷ Def[Spé]) + 2) × CC × R ÷ 100) *mod
        int damage =(int) (((((((2*pokemon.getLvl()/5f)+2f)*pouvoir)*(att/def))/50f)+2f)*cc*mod*R/100);
        adverse.setActualLife(adverse.getActualLife()-damage);
        if (adverse.getActualLife()<=0){
            adverse.setActualLife(0);
            adverse.setKO(true);
            return true;
        }
        return false;
    }

    private float calcMod(Pokemon adverse){
        float STAB = 1f;
        if (pokemon.getTypeElement()==this.type){
            STAB = 1.5f;
        }
        float type = TypeTable.getEffectiveness(adverse.getTypeElement().ordinal(),this.getTypeElement().ordinal());
        float r = (float) Math.ceil((Math.random()) + (precision / 100f));
        //float mod = weather * critical * random * STAB *type;
        float mod = (STAB * type * r);
        return mod;
    }

    public void setCriticalChance(float criticalChance) {
        this.criticalChance = criticalChance;
    }
}
