<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="emerald" tilewidth="16" tileheight="16" tilecount="6072" columns="88">
 <image source="tilesetEmerald.png" width="1408" height="1104"/>
</tileset>
